<?php
include('connexion.php');

$log = htmlspecialchars($_POST['login']);
$pass = htmlspecialchars($_POST['pass']);
//$PC = md5($pass);

//execution de la req
$req = "select * from users where login='$log' and  PASSWD='$pass'";
$rs = mysqli_query($connexion , $req);
//verif resultat
if(!$rs){
    die("Erreur lors de l'exécution de la requête :".mysqli_error($connexion));
}
//Utiliser de mysqli_fetch_assoc pour obtenir les résultats sous forme de tableau associatif
while($u = mysqli_fetch_assoc($rs)){
    // .... traitement des résultats

    session_start();
    $_SESSION['NIV']=$u['niveau'];
    header("location:afficherEtudiant.php");
}
mysqli_close($connexion);

?>