<?php
include("connexion.php");
include("verifier1.php");
include("verifier2.php");

$code =$_GET['code'];
//Exécution d'une requête SQL
$req = "select * from etudiant where code = '$code'";
$rs = mysqli_query($connexion, $req);
// vérification du résultat

if(!$rs){
    dir("Erreur lors de l'exécution de la requette : ". mysqli_error($connexion));

}
$ET = mysqli_fetch_assoc($r);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="modifierEtudiant.php" enctype="multipart/form-data">
        <table>
            <tr>
                <td>Code</td>
                <td><?php echo($ET['code']) ?> <input type="hidden" name="code" value="<?php echo ($ET['code'])?>"></td>
            </tr>
            <tr>
                <td>Nom</td>
                <td><input type="text" name="nom" value="<?php echo ($ET['nom'])?>"></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><input type="email" name="email" value="<?php echo ($ET['email'])?>"></td>
            </tr>
            <tr>
                <td>Photo</td>
                <td><img src="images/<?php echo ('Photo'); ?>"/>
                <input type="file" name="photo">
            </td>
               
            </tr>
            <td></td>
            <td><input type="submit"  value="Enregistrer"></td>

</table>
</form>


</body>
</html>
<?php

mysqli_free_result($rs);
mysqli_close($connexion);

?>