<?php
if($_SESSION['NIV']!=0){
    header("location:index.html");
    exit;
}
?>