<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    

<?php
include('verifier1.php');
include('connexion.php');

$req = "select * from etudiants";
$rs = mysqli_query($connexion, $req);

// On vérifie le résultat
if (!$rs) {
    die("erreur lors de la connexion : " . mysqli_error($connexion));
}
?>
<table border="1">
    <tr>
        <th>Code</th>
        <th>Nom</th>
        <th>Photo</th>
        <?php if ($_SESSION['NIV'] == 0) { ?>
            <th>Actions</th>
        <?php } ?>
    </tr>
    <?php while ($ET = mysqli_fetch_assoc($rs)) { ?>
        <tr>
            <td><?php echo $ET['code']; ?></td>
            <td><?php echo $ET['nom']; ?></td>
            <td><img src="images/<?php echo $ET['photo']; ?>" alt=""></td>
            <?php if ($_SESSION['NIV'] == 0) { ?>
                <td><a href="supprimerEtudiants.php?code=<?php echo $ET['code']; ?>">Supprimer</a></td>
                <td><a href="EditerEtudiants.php?code=<?php echo $ET['code']; ?>">Editer</a></td>
            <?php } ?>
        </tr>
    <?php } ?>

</table>

<style>
    table{
        display:flex;
        align-items:center;
        justify-content:center;

    }
            img{
                width:150px;
                height:150px;
            }
</style>



</body>
</html>