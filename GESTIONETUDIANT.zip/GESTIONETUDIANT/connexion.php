
<?php
//connexion a la base de données 
$connexion = mysqli_connect ( "localhost","root","","g_sco");
if(!$connexion){
    die("La connexion a la base de données a echoué :". mysqli_connect_error());
}